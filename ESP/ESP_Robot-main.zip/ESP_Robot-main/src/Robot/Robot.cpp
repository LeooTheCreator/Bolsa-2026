#include "Robot.h"

RobotClass::RobotClass(){}

void RobotClass::begin(){
  WebPage.begin();
  Serial.begin(9600);
}

void RobotClass::update(){
  WebPage.update();

  String cmd = WebPage.query(); // FIX: lê uma vez por ciclo, não múltiplas vezes

  if(cmd == "FORWARD"){
    Right_Motor.FadeForward();
    Left_Motor.FadeForward();
    Serial.println("FORWARD");
  }
  else if(cmd == "BACKWARD"){
    Right_Motor.FadeBackward();
    Left_Motor.FadeBackward();
    Serial.println("BACKWARD");
  }
  else if(cmd == "RIGHT"){
    Right_Motor.FadeBackward();
    Left_Motor.FadeForward();
    Serial.println("RIGHT");
  }
  else if(cmd == "LEFT"){
    Right_Motor.FadeForward();
    Left_Motor.FadeBackward();
    Serial.println("LEFT");
  }
  else if(cmd == "FORWARD_RIGHT"){
    Right_Motor.FadeForward(127);
    Left_Motor.FadeForward(255);
    Serial.println("FORWARD_RIGHT");
  }
  else if(cmd == "FORWARD_LEFT"){
    Right_Motor.FadeForward(255);
    Left_Motor.FadeForward(127);
    Serial.println("FORWARD_LEFT");
  }
  else if(cmd == "BACKWARD_RIGHT"){
    Right_Motor.FadeBackward(127);
    Left_Motor.FadeBackward(255);
    Serial.println("BACKWARD_RIGHT");
  }
  else if(cmd == "BACKWARD_LEFT"){
    Right_Motor.FadeBackward(255);
    Left_Motor.FadeBackward(127);
    Serial.println("BACKWARD_LEFT");
  }
  else{ // STOP ou qualquer outro valor
    Right_Motor.FadeStop();
    Left_Motor.FadeStop();
    Serial.println("STOPPED");
  }

  Right_Motor.update();
  Left_Motor.update();
}

RobotClass Robot;
