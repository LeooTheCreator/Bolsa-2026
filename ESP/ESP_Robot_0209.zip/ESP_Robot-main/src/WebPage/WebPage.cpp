#include "WebPage.h"

WebPageClass::WebPageClass(const char* ssid, const char* password){
  SSID = ssid;
  PASSWORD = password;
}

String WebPageClass::GetPage(){
  return R"rawliteral(
<!DOCTYPE html>
<html lang="pt-BR" data-bs-theme="dark">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
  <title>Robo CTISMART</title>

  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css"
    rel="stylesheet">
</head>

<body class="bg-dark min-vh-100">

  <nav class="navbar navbar-expand bg-body-tertiary border-bottom border-secondary shadow-sm">
    <div class="container">
      <span class="navbar-brand fw-bold mb-0">🤖 CTISMART</span>
      <a
        class="btn btn-outline-primary"
        href="https://www.ufsm.br/unidades-universitarias/ctism"
        target="_blank"
        rel="noopener noreferrer">
        Saiba mais
      </a>
    </div>
  </nav>

  <main class="container py-4">

    <div class="row justify-content-center mb-4">
      <div class="col-12 col-xl-10">
        <div class="card border-secondary shadow-lg">
          <div class="card-body d-flex flex-column flex-md-row align-items-center justify-content-between gap-3">
            <div>
              <h1 class="h4 mb-1">Robo CTISMART</h1>
              <p class="text-body-secondary mb-0">Controle de movimento e braços</p>
            </div>

            <span class="badge rounded-pill text-bg-success px-3 py-2">
              Online
            </span>
          </div>
        </div>
      </div>
    </div>

    <div class="row g-4 justify-content-center align-items-stretch">

      <!-- BRAÇO ESQUERDO -->
      <div class="col-12 col-md-3">
        <div class="card h-100 border-primary shadow-lg text-center">
          <div class="card-body d-flex flex-column justify-content-center">
            <div class="display-1 mb-2">🦾</div>
            <h2 class="h5">Braço esquerdo</h2>
            <p class="small text-body-secondary">Servo independente</p>

            <div class="d-grid gap-3 mt-3">
              <button
                type="button"
                class="btn btn-primary btn-lg py-3"
                ontouchstart="servoMove('left',10)"
                onmousedown="servoMove('left',10)">
                ▲ Levantar
              </button>

              <button
                type="button"
                class="btn btn-outline-primary btn-lg py-3"
                ontouchstart="servoMove('left',-10)"
                onmousedown="servoMove('left',-10)">
                ▼ Abaixar
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- MOVIMENTO -->
      <div class="col-12 col-md-6">
        <div class="card h-100 border-secondary shadow-lg">
          <div class="card-header text-center py-3">
            <strong>Movimento</strong>
          </div>

          <div class="card-body d-flex align-items-center">
            <div class="container-fluid px-0">

              <div class="row row-cols-3 g-2 justify-content-center">
                <div class="col"></div>

                <div class="col d-grid">
                  <button
                    type="button"
                    class="btn btn-primary btn-lg py-4 fs-2"
                    ontouchstart="p('F')"
                    ontouchend="r('F')"
                    ontouchcancel="r('F')"
                    onmousedown="p('F')"
                    onmouseup="r('F')"
                    onmouseleave="r('F')">
                    ▲
                  </button>
                </div>

                <div class="col"></div>

                <div class="col d-grid">
                  <button
                    type="button"
                    class="btn btn-primary btn-lg py-4 fs-2"
                    ontouchstart="p('L')"
                    ontouchend="r('L')"
                    ontouchcancel="r('L')"
                    onmousedown="p('L')"
                    onmouseup="r('L')"
                    onmouseleave="r('L')">
                    ◀
                  </button>
                </div>

                <div class="col d-grid">
                  <button
                    type="button"
                    class="btn btn-danger btn-lg py-4 fs-2"
                    ontouchstart="p('S')"
                    ontouchend="r('S')"
                    ontouchcancel="r('S')"
                    onmousedown="p('S')"
                    onmouseup="r('S')"
                    onmouseleave="r('S')">
                    ■
                  </button>
                </div>

                <div class="col d-grid">
                  <button
                    type="button"
                    class="btn btn-primary btn-lg py-4 fs-2"
                    ontouchstart="p('R')"
                    ontouchend="r('R')"
                    ontouchcancel="r('R')"
                    onmousedown="p('R')"
                    onmouseup="r('R')"
                    onmouseleave="r('R')">
                    ▶
                  </button>
                </div>

                <div class="col"></div>

                <div class="col d-grid">
                  <button
                    type="button"
                    class="btn btn-primary btn-lg py-4 fs-2"
                    ontouchstart="p('B')"
                    ontouchend="r('B')"
                    ontouchcancel="r('B')"
                    onmousedown="p('B')"
                    onmouseup="r('B')"
                    onmouseleave="r('B')">
                    ▼
                  </button>
                </div>

                <div class="col"></div>
              </div>

            </div>
          </div>
        </div>
      </div>

      <!-- BRAÇO DIREITO -->
      <div class="col-12 col-md-3">
        <div class="card h-100 border-info shadow-lg text-center">
          <div class="card-body d-flex flex-column justify-content-center">
            <div class="display-1 mb-2">🦾</div>
            <h2 class="h5">Braço direito</h2>
            <p class="small text-body-secondary">Servo independente</p>

            <div class="d-grid gap-3 mt-3">
              <button
                type="button"
                class="btn btn-info btn-lg py-3"
                ontouchstart="servoMove('right',10)"
                onmousedown="servoMove('right',10)">
                ▲ Levantar
              </button>

              <button
                type="button"
                class="btn btn-outline-info btn-lg py-3"
                ontouchstart="servoMove('right',-10)"
                onmousedown="servoMove('right',-10)">
                ▼ Abaixar
              </button>
            </div>
          </div>
        </div>
      </div>

    </div>

  </main>

  <script>
    let s = {};

    let interval = setInterval(send, 100);

    function p(d){
      s[d] = true;
      send();
    }

    function r(d){
      delete s[d];
      send();
    }

    function send(){
      let cmd = 'STOP';

      if(s.S)
        cmd = 'STOP';
      else if(s.F && s.L)
        cmd = 'FORWARD_LEFT';
      else if(s.F && s.R)
        cmd = 'FORWARD_RIGHT';
      else if(s.B && s.L)
        cmd = 'BACKWARD_LEFT';
      else if(s.B && s.R)
        cmd = 'BACKWARD_RIGHT';
      else if(s.F)
        cmd = 'FORWARD';
      else if(s.B)
        cmd = 'BACKWARD';
      else if(s.L)
        cmd = 'LEFT';
      else if(s.R)
        cmd = 'RIGHT';

      fetch('/move?dir=' + cmd)
        .catch(() => {});
    }

    function servoMove(arm, amount){
      fetch('/servo?arm=' + arm + '&move=' + amount)
        .catch(() => {});
    }
  </script>

</body>
</html>
)rawliteral";
}

void WebPageClass::begin(){
  WiFi.softAP(SSID, PASSWORD);

  MDNS.begin("roboctismart");

  server.on("/", [this](){
    server.send(
      200,
      "text/html",
      GetPage()
    );
  });

  server.on("/move", [this](){
    if(server.hasArg("dir")){
      currentCommand = server.arg("dir");
      lastCommandTime = millis();
    }

    server.send(
      200,
      "text/plain",
      "OK"
    );
  });

  server.on("/servo", [this](){
    if(server.hasArg("arm") && server.hasArg("move")){
      String arm = server.arg("arm");
      String movement = server.arg("move");

      if(arm == "left"){
        currentLeftServoCommand = movement;
      }
      else if(arm == "right"){
        currentRightServoCommand = movement;
      }
    }

    server.send(
      200,
      "text/plain",
      "OK"
    );
  });

  server.onNotFound([this](){
    server.send(
      404,
      "text/plain",
      "Not Found"
    );
  });

  server.begin();
}

void WebPageClass::update(){
  server.handleClient();

  if(
    currentCommand != "STOP" &&
    (millis() - lastCommandTime > 300)
  ){
    currentCommand = "STOP";
  }
}

String WebPageClass::query(){
  return currentCommand;
}

String WebPageClass::leftServoQuery(){
  String command = currentLeftServoCommand;
  currentLeftServoCommand = "0";
  return command;
}

String WebPageClass::rightServoQuery(){
  String command = currentRightServoCommand;
  currentRightServoCommand = "0";
  return command;
}

WebPageClass WebPage(
  "Robo_CTISMART",
  "Abacaxi123"
);
