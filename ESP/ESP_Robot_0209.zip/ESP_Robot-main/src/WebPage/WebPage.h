#pragma once

#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <ESPmDNS.h>

class WebPageClass{
  public:
    WebPageClass(const char* ssid, const char* password);

    String GetPage();
    void begin();
    String query();
    String leftServoQuery();
    String rightServoQuery();
    void update();

  private:
    WebServer server{80};

    const char* SSID;
    const char* PASSWORD;

    String currentCommand = "STOP";
    String currentLeftServoCommand = "0";
    String currentRightServoCommand = "0";

    unsigned long lastCommandTime = 0;
};

extern WebPageClass WebPage;
