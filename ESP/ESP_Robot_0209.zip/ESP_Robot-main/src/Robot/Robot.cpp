#include "Robot.h"

RobotClass::RobotClass(){}

void RobotClass::begin(){
  WebPage.begin();

  Serial.begin(9600);

  Servo_LeftArm.begin();
  Servo_RightArm.begin();
}

void RobotClass::update(){

  // Atualiza a página web.
  WebPage.update();

  // Movimento dos motores.
  String command = WebPage.query();

  if(command == "FORWARD"){
    Right_Motor.FadeForward();
    Left_Motor.FadeForward();
    Serial.println("FORWARD");
  }
  else if(command == "BACKWARD"){
    Right_Motor.FadeBackward();
    Left_Motor.FadeBackward();
    Serial.println("BACKWARD");
  }
  else if(command == "RIGHT"){
    Right_Motor.FadeBackward();
    Left_Motor.FadeForward();
    Serial.println("RIGHT");
  }
  else if(command == "LEFT"){
    Right_Motor.FadeForward();
    Left_Motor.FadeBackward();
    Serial.println("LEFT");
  }
  else if(command == "FORWARD_RIGHT"){
    Right_Motor.FadeForward(127);
    Left_Motor.FadeForward(255);
    Serial.println("FORWARD_RIGHT");
  }
  else if(command == "FORWARD_LEFT"){
    Right_Motor.FadeForward(255);
    Left_Motor.FadeForward(127);
    Serial.println("FORWARD_LEFT");
  }
  else if(command == "BACKWARD_RIGHT"){
    Right_Motor.FadeBackward(127);
    Left_Motor.FadeBackward(255);
    Serial.println("BACKWARD_RIGHT");
  }
  else if(command == "BACKWARD_LEFT"){
    Right_Motor.FadeBackward(255);
    Left_Motor.FadeBackward(127);
    Serial.println("BACKWARD_LEFT");
  }
  else{
    Right_Motor.FadeStop();
    Left_Motor.FadeStop();
    Serial.println("STOPPED");
  }

  // Comando do braço esquerdo.
  String leftServoCommand = WebPage.leftServoQuery();

  if(leftServoCommand != "0"){
    int movement = leftServoCommand.toInt();
    int newAngle = Servo_LeftArm.getAngle() + movement;
    newAngle = constrain(newAngle, 0, 180);

    Servo_LeftArm.Move(newAngle);

    Serial.print("LEFT ARM: ");
    Serial.println(newAngle);
  }

  // Comando do braço direito.
  String rightServoCommand = WebPage.rightServoQuery();

  if(rightServoCommand != "0"){
    int movement = rightServoCommand.toInt();
    int newAngle = Servo_RightArm.getAngle() + movement;
    newAngle = constrain(newAngle, 0, 180);

    Servo_RightArm.Move(newAngle);

    Serial.print("RIGHT ARM: ");
    Serial.println(newAngle);
  }

  Right_Motor.update();
  Left_Motor.update();

  Servo_LeftArm.update();
  Servo_RightArm.update();
}

RobotClass Robot;
