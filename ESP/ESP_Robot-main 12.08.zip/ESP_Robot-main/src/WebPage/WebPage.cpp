#include "WebPage.h"

WebPageClass::WebPageClass(const char* ssid, const char* password){
  SSID = ssid;
  PASSWORD = password;
}


String WebPageClass::GetPage(){
  return R"rawliteral(
<!DOCTYPE html>
<html>

<head>

  <meta name="viewport"
        content="width=device-width, initial-scale=1.0, user-scalable=no">

  <style>

    *{
      margin:0;
      padding:0;
      box-sizing:border-box;
      touch-action:none;
      user-select:none;
      -webkit-user-select:none;
    }

    body{
      min-height:100vh;
      display:flex;
      justify-content:center;
      align-items:center;

      background:
        radial-gradient(circle at top,#2d5fff,#101625 60%),
        linear-gradient(180deg,#111,#050505);

      font-family:Arial, Helvetica, sans-serif;
    }

    .container{
      display:flex;
      flex-direction:column;
      align-items:center;
    }

    .dpad{
      display:grid;
      grid-template-columns:repeat(3, min(22vw,95px));
      gap:min(2vw,12px);

      padding:20px;
      border-radius:30px;

      background:rgba(255,255,255,.05);
      backdrop-filter:blur(15px);

      box-shadow:
        0 0 30px rgba(0,0,0,.5),
        inset 0 0 15px rgba(255,255,255,.08);
    }

    .dpad button{
      width:min(22vw,95px);
      height:min(22vw,95px);

      border:none;
      border-radius:22px;

      font-size:min(8vw,36px);
      color:white;

      cursor:pointer;

      background:linear-gradient(145deg,#4c6fff,#2448dd);

      box-shadow:
        0 8px 18px rgba(0,0,0,.45),
        inset 0 2px 5px rgba(255,255,255,.3);

      transition:
        transform .08s,
        background .2s,
        box-shadow .2s;
    }

    .dpad button:hover{
      background:linear-gradient(145deg,#6282ff,#2b55ff);
    }

    .dpad button:active{
      transform:scale(.93);

      background:linear-gradient(145deg,#203dc7,#142f9b);

      box-shadow:
        inset 0 5px 12px rgba(0,0,0,.45);
    }

    .blank{
      visibility:hidden;
    }

    /* Botão STOP */

    .dpad button:nth-child(5){
      background:linear-gradient(145deg,#ff5656,#c81414);
    }

    .dpad button:nth-child(5):hover{
      background:linear-gradient(145deg,#ff6d6d,#df2222);
    }

    .dpad button:nth-child(5):active{
      background:linear-gradient(145deg,#a90f0f,#7f0909);
    }

    /* Controle do servo */

    .servo-control{
      display:flex;
      justify-content:center;
      gap:12px;
      margin-top:20px;
    }

    .servo-control button{
      width:140px;
      height:55px;

      border:none;
      border-radius:15px;

      background:linear-gradient(145deg,#4c6fff,#2448dd);

      color:white;
      font-size:16px;

      cursor:pointer;

      box-shadow:
        0 6px 15px rgba(0,0,0,.4),
        inset 0 2px 5px rgba(255,255,255,.2);
    }

    .servo-control button:active{
      transform:scale(.95);
    }

    /* Celulares pequenos */

    @media(max-width:500px){

      .dpad{
        padding:15px;
        gap:10px;
      }

      .servo-control button{
        width:120px;
      }

    }

  </style>

</head>


<body>

  <div class="container">

    <!-- CONTROLE DOS MOTORES -->

    <div class="dpad">

      <div class="blank"></div>

      <button
        ontouchstart="p('F')"
        ontouchend="r('F')"
        onmousedown="p('F')"
        onmouseup="r('F')">
        &#9650;
      </button>

      <div class="blank"></div>


      <button
        ontouchstart="p('L')"
        ontouchend="r('L')"
        onmousedown="p('L')"
        onmouseup="r('L')">
        &#9668;
      </button>


      <button
        ontouchstart="p('S')"
        ontouchend="r('S')"
        onmousedown="p('S')"
        onmouseup="r('S')"
        style="background:#c0392b;">
        &#9632;
      </button>


      <button
        ontouchstart="p('R')"
        ontouchend="r('R')"
        onmousedown="p('R')"
        onmouseup="r('R')">
        &#9658;
      </button>


      <div class="blank"></div>


      <button
        ontouchstart="p('B')"
        ontouchend="r('B')"
        onmousedown="p('B')"
        onmouseup="r('B')">
        &#9660;
      </button>

      <div class="blank"></div>

    </div>


    <!-- CONTROLE DO SERVO -->

    <div class="servo-control">

      <button
        ontouchstart="servoMove(-10)"
        onmousedown="servoMove(-10)">
        ◀ BAIXO
      </button>

      <button
        ontouchstart="servoMove(10)"
        onmousedown="servoMove(10)">
        CIMA ▶
      </button>

    </div>

  </div>


  <script>

    let s = {};

    /*
      Envia comandos dos motores
      a cada 100 ms.
    */

    let interval = setInterval(send, 100);


    /*
      Quando apertamos um botão
      de movimento.
    */

    function p(d){
      s[d] = true;
      send();
    }


    /*
      Quando soltamos um botão
      de movimento.
    */

    function r(d){
      delete s[d];
      send();
    }


    /*
      Decide qual comando deve
      ser enviado aos motores.
    */

    function send(){

      let cmd = 'STOP';

      if(s.F && s.L)
        cmd = 'FORWARD_LEFT';

      else if(s.F && s.R)
        cmd = 'FORWARD_RIGHT';

      else if(s.B && s.L)
        cmd = 'BACKWARD_LEFT';

      else if(s.B && s.R)
        cmd = 'BACKWARD_RIGHT';

      else if(s.F)
        cmd = 'FORWARD';

      else if(s.B)
        cmd = 'BACKWARD';

      else if(s.L)
        cmd = 'LEFT';

      else if(s.R)
        cmd = 'RIGHT';

      fetch('/move?dir=' + cmd)
        .catch(() => {});

    }


    /*
      Movimento do servo.

      -10 = esquerda
      +10 = direita
    */

    function servoMove(amount){

      fetch('/servo?move=' + amount)
        .catch(() => {});

    }

  </script>

</body>

</html>
)rawliteral";
}


void WebPageClass::begin(){

  WiFi.softAP(SSID, PASSWORD);

  MDNS.begin("roboctismart");


  /*
    Página principal
  */

  server.on("/", [this](){

    server.send(
      200,
      "text/html",
      GetPage()
    );

  });


  /*
    Comandos dos motores
  */

  server.on("/move", [this](){

    if(server.hasArg("dir")){

      currentCommand = server.arg("dir");

      lastCommandTime = millis();

    }

    server.send(
      200,
      "text/plain",
      "OK"
    );

  });


  /*
    Comandos do servo
  */

  server.on("/servo", [this](){

    if(server.hasArg("move")){

      currentServoCommand = server.arg("move");

    }

    server.send(
      200,
      "text/plain",
      "OK"
    );

  });


  /*
    Página inexistente
  */

  server.onNotFound([this](){

    server.send(
      404,
      "text/plain",
      "Not Found"
    );

  });


  server.begin();

}


void WebPageClass::update(){

  server.handleClient();


  /*
    Se o ESP32 ficar mais de 300 ms
    sem receber comando dos motores,
    automaticamente para.
  */

  if(
    currentCommand != "STOP" &&
    (millis() - lastCommandTime > 300)
  ){

    currentCommand = "STOP";

  }

}


String WebPageClass::query(){

  return currentCommand;

}


String WebPageClass::servoQuery(){

  String command = currentServoCommand;

  /*
    Depois que o Robot pegar o comando,
    voltamos para 0.
  */

  currentServoCommand = "0";

  return command;

}


WebPageClass WebPage(
  "Robo_CTISMART",
  "Abacaxi123"
);