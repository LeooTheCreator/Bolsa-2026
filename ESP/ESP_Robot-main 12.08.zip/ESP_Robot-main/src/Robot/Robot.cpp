#include "Robot.h"


RobotClass::RobotClass(){}


void RobotClass::begin(){

  WebPage.begin();

  Serial.begin(9600);

  Servo_Motor.begin();

}


void RobotClass::update(){

  /*
    Atualiza a página web
  */

  WebPage.update();


  /*
    Verifica comandos dos motores
  */

  if(WebPage.query() == "FORWARD"){

    Right_Motor.FadeForward();
    Left_Motor.FadeForward();

    Serial.println("FORWARD");

  }

  else if(WebPage.query() == "BACKWARD"){

    Right_Motor.FadeBackward();
    Left_Motor.FadeBackward();

    Serial.println("BACKWARD");

  }

  else if(WebPage.query() == "RIGHT"){

    Right_Motor.FadeBackward();
    Left_Motor.FadeForward();

    Serial.println("RIGHT");

  }

  else if(WebPage.query() == "LEFT"){

    Right_Motor.FadeForward();
    Left_Motor.FadeBackward();

    Serial.println("LEFT");

  }

  else if(WebPage.query() == "FORWARD_RIGHT"){

    Right_Motor.FadeForward(127);
    Left_Motor.FadeForward(255);

    Serial.println("FORWARD_RIGHT");

  }

  else if(WebPage.query() == "FORWARD_LEFT"){

    Right_Motor.FadeForward(255);
    Left_Motor.FadeForward(127);

    Serial.println("FORWARD_LEFT");

  }

  else if(WebPage.query() == "BACKWARD_RIGHT"){

    Right_Motor.FadeBackward(127);
    Left_Motor.FadeBackward(255);

    Serial.println("BACKWARD_RIGHT");

  }

  else if(WebPage.query() == "BACKWARD_LEFT"){

    Right_Motor.FadeBackward(255);
    Left_Motor.FadeBackward(127);

    Serial.println("BACKWARD_LEFT");

  }

  else{

    Right_Motor.FadeStop();
    Left_Motor.FadeStop();

    Serial.println("STOPPED");

  }


  /*
    Pega um possível comando do servo.
  */

  String servoCommand = WebPage.servoQuery();


  /*
    Se recebeu alguma coisa diferente
    de "0", movimenta o servo.
  */

  if(servoCommand != "0"){

    int movement = servoCommand.toInt();


    /*
      Pega o ângulo atual
      e adiciona o movimento.

      Exemplo:

      90 + 10 = 100
      90 - 10 = 80
    */

    int newAngle =
      Servo_Motor.getAngle() + movement;


    /*
      Impede o servo de passar
      de 0° ou 180°.
    */

    newAngle = constrain(
      newAngle,
      0,
      180
    );


    Servo_Motor.Move(newAngle);


    Serial.print("SERVO: ");

    Serial.println(newAngle);

  }


  /*
    Atualiza os motores.
  */

  Right_Motor.update();

  Left_Motor.update();


  /*
    Atualiza o servo.
  */

  Servo_Motor.update();

}


RobotClass Robot;