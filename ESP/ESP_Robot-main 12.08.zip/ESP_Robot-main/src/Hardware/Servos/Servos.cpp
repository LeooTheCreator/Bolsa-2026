#include "Servos.h"

ServosClass::ServosClass(int pin){
  PIN = pin;
}

void ServosClass::begin(){
  servo.attach(PIN);
  servo.write(currentAngle);
}

void ServosClass::Move(int angle){
  targetAngle = constrain(angle, 0, 180);
}

void ServosClass::Stop(){
  targetAngle = currentAngle;
}

void ServosClass::update(){
  if(currentAngle == targetAngle) return;

  if(millis() - lastUpdate < 10) return;

  lastUpdate = millis();

  if(currentAngle < targetAngle){
    currentAngle++;
  }
  else{
    currentAngle--;
  }

  servo.write(currentAngle);
}

int ServosClass::getAngle(){
  return currentAngle;
}

ServosClass Servo_Motor(33);