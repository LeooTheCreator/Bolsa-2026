# Robo CTISMART - celular

A interface usa Bootstrap 5.3 local, dentro de `data/bootstrap.min.css`.

## Primeira gravação

No PlatformIO:

1. Conecte o ESP8266.
2. Execute `PlatformIO: Build Filesystem Image`.
3. Execute `PlatformIO: Upload Filesystem Image`.
4. Execute `PlatformIO: Upload`.
5. Conecte o celular ao Wi-Fi `Robo_CTISMART`.
6. Abra `http://192.168.4.1`.

## Importante

O `bootstrap.min.css` precisa estar dentro da pasta `data/` e o filesystem precisa ser enviado ao ESP8266.
Se o monitor serial mostrar `Bootstrap encontrado`, a página terá o layout Bootstrap.

A interface foi organizada para celular:
- braços lado a lado;
- movimento em grade 3x3;
- botões grandes para toque;
- oito direções;
- botão de parada;
- braços visuais espelhados para esquerda/direita.
