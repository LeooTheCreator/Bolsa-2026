#include "WebPage.h"

WebPageClass::WebPageClass(const char* ssid, const char* password){
  SSID = ssid;
  PASSWORD = password;
}

String WebPageClass::GetPage(){
  return R"rawliteral(
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <meta name="theme-color" content="#212529">
  <title>Robo CTISMART</title>

  <!-- Bootstrap local: funciona mesmo sem internet -->
  <link rel="stylesheet" href="/bootstrap.min.css">
</head>

<body class="bg-dark text-light min-vh-100">

<nav class="navbar navbar-dark bg-dark border-bottom border-secondary">
  <div class="container-fluid px-2 px-sm-3">
    <span class="navbar-brand fw-bold mb-0">🤖 CTISMART</span>
    <a class="btn btn-outline-light btn-sm" href="https://www.ufsm.br/unidades-universitarias/ctism" target="_blank">
      Saiba mais
    </a>
  </div>
</nav>

<main class="container-fluid py-2 py-sm-3 px-2 px-sm-3">
  <div class="row justify-content-center">
    <div class="col-12 col-xl-10">

      <div class="card bg-dark border-secondary shadow-sm mb-2 mb-sm-3">
        <div class="card-body py-2 py-sm-3 d-flex flex-column flex-sm-row align-items-center justify-content-between gap-2">
          <div class="text-center text-sm-start">
            <h1 class="h4 mb-1">Robo CTISMART</h1>
            <p class="text-secondary mb-0">Controle de movimento e braços</p>
          </div>
          <span class="badge text-bg-success rounded-pill px-3 py-2">● Online</span>
        </div>
      </div>

      <!--
        CELULAR:
        braços ficam lado a lado em colunas 6 + 6.
        movimento fica abaixo e ocupa a largura inteira.

        DESKTOP:
        braço esquerdo | movimento | braço direito
      -->
      <div class="row g-2 g-md-3 align-items-stretch">

        <!-- BRAÇO ESQUERDO -->
        <div class="col-6 col-md-3 col-xl-2 order-1">
          <div class="card h-100 bg-dark border-primary shadow-sm">
            <div class="card-body text-center d-flex flex-column p-2 p-sm-3">

              <!-- Espelhado para apontar para a esquerda -->
              <div class="display-3 display-sm-1 mb-1"
                   style="transform: rotate(-28deg) scaleX(-1);">
                🦾
              </div>

              <h2 class="h6 h5-sm mb-1">Braço esquerdo</h2>
              <p class="small text-secondary mb-2 mb-sm-3">Servo independente</p>

              <div class="d-grid gap-2 mt-auto">
                <button type="button"
                        class="btn btn-primary btn-lg py-2 py-sm-3"
                        onclick="servoMove('left',10)">
                  ▲ Levantar
                </button>

                <button type="button"
                        class="btn btn-outline-primary btn-lg py-2 py-sm-3"
                        onclick="servoMove('left',-10)">
                  ▼ Abaixar
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- BRAÇO DIREITO -->
        <div class="col-6 col-md-3 col-xl-2 order-2 order-md-3">
          <div class="card h-100 bg-dark border-info shadow-sm">
            <div class="card-body text-center d-flex flex-column p-2 p-sm-3">

              <!-- Espelhado para apontar para a direita -->
              <div class="display-3 display-sm-1 mb-1"
                   style="transform: rotate(28deg);">
                🦾
              </div>

              <h2 class="h6 h5-sm mb-1">Braço direito</h2>
              <p class="small text-secondary mb-2 mb-sm-3">Servo independente</p>

              <div class="d-grid gap-2 mt-auto">
                <button type="button"
                        class="btn btn-info btn-lg py-2 py-sm-3"
                        onclick="servoMove('right',10)">
                  ▲ Levantar
                </button>

                <button type="button"
                        class="btn btn-outline-info btn-lg py-2 py-sm-3"
                        onclick="servoMove('right',-10)">
                  ▼ Abaixar
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- MOVIMENTO -->
        <div class="col-12 col-md-6 col-xl-8 order-3 order-md-2">
          <div class="card h-100 bg-dark border-secondary shadow-sm">
            <div class="card-header text-center py-2">
              <strong>🕹️ Movimento</strong>
            </div>

            <div class="card-body p-2 p-sm-3 d-flex align-items-center">
              <div class="container-fluid px-0">

                <!-- 8 direções + STOP -->
                <div class="row g-2">

                  <div class="col-4 d-grid">
                    <button class="btn btn-primary btn-lg py-3 py-sm-4 fs-2"
                            onpointerdown="p(event,'FL')"
                            onpointerup="r(event,'FL')"
                            onpointercancel="r(event,'FL')"
                            onpointerleave="r(event,'FL')">↖</button>
                  </div>

                  <div class="col-4 d-grid">
                    <button class="btn btn-primary btn-lg py-3 py-sm-4 fs-2"
                            onpointerdown="p(event,'F')"
                            onpointerup="r(event,'F')"
                            onpointercancel="r(event,'F')"
                            onpointerleave="r(event,'F')">▲</button>
                  </div>

                  <div class="col-4 d-grid">
                    <button class="btn btn-primary btn-lg py-3 py-sm-4 fs-2"
                            onpointerdown="p(event,'FR')"
                            onpointerup="r(event,'FR')"
                            onpointercancel="r(event,'FR')"
                            onpointerleave="r(event,'FR')">↗</button>
                  </div>

                  <div class="col-4 d-grid">
                    <button class="btn btn-primary btn-lg py-3 py-sm-4 fs-2"
                            onpointerdown="p(event,'L')"
                            onpointerup="r(event,'L')"
                            onpointercancel="r(event,'L')"
                            onpointerleave="r(event,'L')">◀</button>
                  </div>

                  <div class="col-4 d-grid">
                    <button class="btn btn-danger btn-lg py-3 py-sm-4 fs-2"
                            onclick="stopRobot()">■</button>
                  </div>

                  <div class="col-4 d-grid">
                    <button class="btn btn-primary btn-lg py-3 py-sm-4 fs-2"
                            onpointerdown="p(event,'R')"
                            onpointerup="r(event,'R')"
                            onpointercancel="r(event,'R')"
                            onpointerleave="r(event,'R')">▶</button>
                  </div>

                  <div class="col-4 d-grid">
                    <button class="btn btn-primary btn-lg py-3 py-sm-4 fs-2"
                            onpointerdown="p(event,'BL')"
                            onpointerup="r(event,'BL')"
                            onpointercancel="r(event,'BL')"
                            onpointerleave="r(event,'BL')">↙</button>
                  </div>

                  <div class="col-4 d-grid">
                    <button class="btn btn-primary btn-lg py-3 py-sm-4 fs-2"
                            onpointerdown="p(event,'B')"
                            onpointerup="r(event,'B')"
                            onpointercancel="r(event,'B')"
                            onpointerleave="r(event,'B')">▼</button>
                  </div>

                  <div class="col-4 d-grid">
                    <button class="btn btn-primary btn-lg py-3 py-sm-4 fs-2"
                            onpointerdown="p(event,'BR')"
                            onpointerup="r(event,'BR')"
                            onpointercancel="r(event,'BR')"
                            onpointerleave="r(event,'BR')">↘</button>
                  </div>

                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
</main>

<script>
  const pressed = {};
  let lastCommand = '';
  let lastTime = 0;

  function p(e, direction){
    e.preventDefault();
    if(e.currentTarget.setPointerCapture){
      try { e.currentTarget.setPointerCapture(e.pointerId); } catch(err) {}
    }
    pressed[direction] = true;
    sendMovement();
  }

  function r(e, direction){
    e.preventDefault();
    delete pressed[direction];
    sendMovement();
  }

  function stopRobot(){
    for(const key in pressed) delete pressed[key];
    fetch('/move?dir=STOP', {cache:'no-store'}).catch(()=>{});
    lastCommand = 'STOP';
    lastTime = Date.now();
  }

  function sendMovement(){
    let command = 'STOP';

    if(pressed.FL) command = 'FORWARD_LEFT';
    else if(pressed.FR) command = 'FORWARD_RIGHT';
    else if(pressed.BL) command = 'BACKWARD_LEFT';
    else if(pressed.BR) command = 'BACKWARD_RIGHT';
    else if(pressed.F && pressed.L) command = 'FORWARD_LEFT';
    else if(pressed.F && pressed.R) command = 'FORWARD_RIGHT';
    else if(pressed.B && pressed.L) command = 'BACKWARD_LEFT';
    else if(pressed.B && pressed.R) command = 'BACKWARD_RIGHT';
    else if(pressed.F) command = 'FORWARD';
    else if(pressed.B) command = 'BACKWARD';
    else if(pressed.L) command = 'LEFT';
    else if(pressed.R) command = 'RIGHT';

    const now = Date.now();

    if(command === lastCommand && command !== 'STOP' && now - lastTime < 80){
      return;
    }

    lastCommand = command;
    lastTime = now;

    fetch('/move?dir=' + encodeURIComponent(command), {
      cache: 'no-store'
    }).catch(()=>{});
  }

  function servoMove(arm, amount){
    fetch('/servo?arm=' + arm + '&move=' + amount, {
      cache: 'no-store'
    }).catch(()=>{});
  }

  // Mantém o movimento atualizado enquanto o botão estiver pressionado.
  setInterval(function(){
    if(Object.keys(pressed).length > 0){
      sendMovement();
    }
  }, 100);
</script>

</body>
</html>
)rawliteral";
}

void WebPageClass::begin(){
  if(!LittleFS.begin()){
    Serial.println("ERRO: nao foi possivel montar o LittleFS.");
  } else {
    Serial.println("LittleFS montado.");

    if(LittleFS.exists("/bootstrap.min.css")){
      File file = LittleFS.open("/bootstrap.min.css", "r");
      Serial.print("Bootstrap encontrado. Tamanho: ");
      Serial.print(file.size());
      Serial.println(" bytes.");
      file.close();
    } else {
      Serial.println("ERRO: /bootstrap.min.css nao encontrado.");
    }
  }

  WiFi.mode(WIFI_AP);
  WiFi.softAP(SSID, PASSWORD);

  Serial.print("IP do robo: ");
  Serial.println(WiFi.softAPIP());

  MDNS.begin("roboctismart");

  server.on("/", [this](){
    server.send(200, "text/html; charset=utf-8", GetPage());
  });

  server.on("/bootstrap.min.css", [this](){
    if(!LittleFS.exists("/bootstrap.min.css")){
      server.send(404, "text/plain; charset=utf-8",
                  "Bootstrap nao encontrado no LittleFS. Execute: pio run -t uploadfs");
      return;
    }

    File file = LittleFS.open("/bootstrap.min.css", "r");

    if(!file){
      server.send(500, "text/plain; charset=utf-8",
                  "Erro ao abrir bootstrap.min.css");
      return;
    }

    server.sendHeader("Cache-Control", "public, max-age=86400");
    server.streamFile(file, "text/css; charset=utf-8");
    file.close();
  });

  server.on("/move", [this](){
    if(server.hasArg("dir")){
      currentCommand = server.arg("dir");
      lastCommandTime = millis();
    }

    server.send(200, "text/plain", "OK");
  });

  server.on("/servo", [this](){
    if(server.hasArg("arm") && server.hasArg("move")){
      String arm = server.arg("arm");
      String movement = server.arg("move");

      if(arm == "left"){
        currentLeftServoCommand = movement;
      }
      else if(arm == "right"){
        currentRightServoCommand = movement;
      }
    }

    server.send(200, "text/plain", "OK");
  });

  server.onNotFound([this](){
    server.send(404, "text/plain", "Not Found");
  });

  server.begin();
  Serial.println("Servidor web iniciado.");
}

void WebPageClass::update(){
  server.handleClient();

  if(currentCommand != "STOP" &&
     millis() - lastCommandTime > 350){
    currentCommand = "STOP";
  }
}

String WebPageClass::query(){
  return currentCommand;
}

String WebPageClass::leftServoQuery(){
  String command = currentLeftServoCommand;
  currentLeftServoCommand = "0";
  return command;
}

String WebPageClass::rightServoQuery(){
  String command = currentRightServoCommand;
  currentRightServoCommand = "0";
  return command;
}

WebPageClass WebPage("Robo_CTISMART", "Abacaxi123");
