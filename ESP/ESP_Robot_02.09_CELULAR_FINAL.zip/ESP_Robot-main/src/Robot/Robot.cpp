#include "Robot.h"

RobotClass::RobotClass(){}

void RobotClass::begin(){
  Serial.begin(115200);

  Right_Motor.begin();
  Left_Motor.begin();

  Servo_LeftArm.begin();
  Servo_RightArm.begin();

  WebPage.begin();
}

void RobotClass::update(){
  WebPage.update();

  String command = WebPage.query();

  if(command == "FORWARD"){
    Right_Motor.FadeForward();
    Left_Motor.FadeForward();
  }
  else if(command == "BACKWARD"){
    Right_Motor.FadeBackward();
    Left_Motor.FadeBackward();
  }
  else if(command == "RIGHT"){
    Right_Motor.FadeBackward();
    Left_Motor.FadeForward();
  }
  else if(command == "LEFT"){
    Right_Motor.FadeForward();
    Left_Motor.FadeBackward();
  }
  else if(command == "FORWARD_RIGHT"){
    Right_Motor.FadeForward(127);
    Left_Motor.FadeForward(255);
  }
  else if(command == "FORWARD_LEFT"){
    Right_Motor.FadeForward(255);
    Left_Motor.FadeForward(127);
  }
  else if(command == "BACKWARD_RIGHT"){
    Right_Motor.FadeBackward(127);
    Left_Motor.FadeBackward(255);
  }
  else if(command == "BACKWARD_LEFT"){
    Right_Motor.FadeBackward(255);
    Left_Motor.FadeBackward(127);
  }
  else{
    Right_Motor.FadeStop();
    Left_Motor.FadeStop();
  }

  String leftServoCommand = WebPage.leftServoQuery();
  if(leftServoCommand != "0"){
    int movement = leftServoCommand.toInt();
    Servo_LeftArm.Move(Servo_LeftArm.getAngle() + movement);
  }

  String rightServoCommand = WebPage.rightServoQuery();
  if(rightServoCommand != "0"){
    // Espelhado: os dois botoes fazem o mesmo movimento fisico.
    int movement = -rightServoCommand.toInt();
    Servo_RightArm.Move(Servo_RightArm.getAngle() + movement);
  }

  Right_Motor.update();
  Left_Motor.update();
  Servo_LeftArm.update();
  Servo_RightArm.update();
}

RobotClass Robot;
