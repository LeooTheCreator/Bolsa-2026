#include "Motors.h"

MotorsClass::MotorsClass(int forward_pin, int backward_pin, int pwm_pin){
  Forward_PIN = forward_pin;
  Backward_PIN = backward_pin;
  PWM_PIN = pwm_pin;
}

void MotorsClass::begin(){
  pinMode(Forward_PIN, OUTPUT);
  pinMode(Backward_PIN, OUTPUT);
  pinMode(PWM_PIN, OUTPUT);
  digitalWrite(Forward_PIN, LOW);
  digitalWrite(Backward_PIN, LOW);
  analogWrite(PWM_PIN, 0);
}

void MotorsClass::FadeForward(uint8_t speed){
  direction = FORWARD;
  targetSpeed = speed;
}

void MotorsClass::FadeBackward(uint8_t speed){
  direction = BACKWARD;
  targetSpeed = speed;
}

void MotorsClass::FadeStop(){
  direction = STOPPED;
  targetSpeed = 0;
}

void MotorsClass::update(){
  if(millis() - lastUpdate < 10) return;
  lastUpdate = millis();

  if(currentSpeed < targetSpeed) currentSpeed++;
  else if(currentSpeed > targetSpeed) currentSpeed--;

  digitalWrite(Forward_PIN, direction == FORWARD ? HIGH : LOW);
  digitalWrite(Backward_PIN, direction == BACKWARD ? HIGH : LOW);
  analogWrite(PWM_PIN, currentSpeed);
}

// NodeMCU / ESP8266. Mapeamento provisório; confira sua fiação.
MotorsClass Right_Motor(D5, D6, D7); // GPIO14, GPIO12, GPIO13
MotorsClass Left_Motor(D8, D3, D4);  // GPIO15, GPIO0, GPIO2
