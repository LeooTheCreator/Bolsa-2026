#pragma once

#include <Arduino.h>
#include <Servo.h>

class ServosClass{
  public:
    ServosClass(int pin);

    void begin();
    void Move(int angle);
    void Stop();
    void update();

    int getAngle();

  private:
    Servo servo;

    int PIN;

    int currentAngle = 90;
    int targetAngle = 90;

    unsigned long lastUpdate = 0;
};

extern ServosClass Servo_LeftArm;
extern ServosClass Servo_RightArm;
